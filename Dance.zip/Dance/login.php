<?php
include 'connect.php';
//session_start();
if(isset($_POST['submit'])){
    $UserID = $_POST['userid'];
    $Password = $_POST['pass'];
    $sql = "SELECT USERID,NAME,PASSWORD FROM reg WHERE USERID =?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$UserID);
    $stmt->execute();

    $stmt->bind_result($db_userid,$db_name,$db_pass);
    	echo "$stmt->error"; 
    if($stmt->fetch())
    {
       // $pass = password_hash($Password, PASSWORD_DEFAULT);
        //echo $pass;
    	$pass_decode = password_verify($Password,$db_pass);
    	//echo $pass_decode."<br>";
    	//echo $db_userid;
           //echo $db_pass;
    	if($pass_decode) 
    	{

    		
    		header("location:packages.html");
    	}else
    	{
    		?>
           <script>
           	alert("INcorrect PASSWORD.....");
           </script>
    	
    		<?php

    	}
    }else{
    	?>
    


    	<script>
    		alert("Incorrect USERID");

    	</script>
    	<?php 
    }
    //echo $db_userid;
   // echo $db_pass;
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>Dance Academy</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="imagesp/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendorp/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fontsp/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fontsp/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendorp/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendorp/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendorp/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendorp/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendorp/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="cssp/util.css">
	<link rel="stylesheet" type="text/css" href="cssp/main.css">
<!--===============================================================================================-->
</head>
<style>
	a{
		color: white;
	}
</style>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('imagesp/e.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
				 Login
				</span>
				<form class="login100-form validate-form p-b-33 p-t-5" action ="login.php" method="post">

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="userid" placeholder="User ID" autocomplete="off" required >
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pass" placeholder="Password" autocomplete="off" required>
						<span class="focus-input100" data-placeholder="&#xe80f;"></span>
					</div>

					<div class="container-login100-form-btn m-t-32">
						<button class="login100-form-btn" name="submit">
							Login
						</button>
					</div>
                    

              		<div class="container-login100-form-btn m-t-32">
              			
						<button class="login100-form-btn" id="d1">
							<a href="signup.php">Signup</a>
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendorp/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendorp/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendorp/bootstrap/js/popper.js"></script>
	<script src="vendorp/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendorp/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendorp/daterangepicker/moment.min.js"></script>
	<script src="vendorp/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendorp/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="jsp/main.js"></script>

</body>
</html>
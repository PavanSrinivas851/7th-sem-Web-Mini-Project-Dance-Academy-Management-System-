<?php

   include 'connect.php';


if(isset($_POST['submit'])){


  $CName = $_POST['n'];
  $cnumber = $_POST['cn'];
  $date = $_POST['ex'];
  $cvv = $_POST['cv'];
  

  

  //template for the sql query
  $sql = "INSERT INTO card(CARDNAME,CARDNO,EXP,CVV) VALUES(?,?,?,?)";

  //preparing the statement
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sssi",$CName,$cnumber,$date,$cvv);//if the user need the parameter then use the bind_param
  $result = $stmt->execute();

  if($result){
    header("location:ty.html");
  }

}




?>

<!DOCTYPE html>
<html>
    <head>
    <title>
        transparent login
    </title>
    <style>
        body{
            margin:0;
            padding:0;
            background: url("o.jpg");
            background-size:cover;
            font-family: sans-serif; 
            color: #fff;
        }
        .loginBox{
position: absolute;
top:50%;
left:25%;
transform: translate(-50%,-50%);
width:350px;
height: 450px;
padding:80px 40px;
box-sizing:border-box;
background: rgba(0,0,0,0.7);
box-shadow: 200px;
box-decoration-break: 20px;



        }
        h2{
            margin: 0;
            padding:0 0 20px;
            color:white;
            text-align:center;

        }
        .loginBox p{
            padding:0;
            margin:0;
            color: #fff;
            font-weight:bold;

        }
        .loginBox input{
            width:100%;
            margin-bottom: 20px;


        }
        .loginBox input[type="text"], .loginBox input[type="password"]
        {
            border: none;
            border-bottom: 1px solid #fff;
            background: transparent;
            outline:none;
            height:40px;
            color:#fff;
            font-size:  16px;

        }


        .loginBox input[type="submit"]
        {
display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  min-width: 160px;
  height: 25px;
  background-color: #bd59d4;
  border-radius: 25px;



font-family: SourceSansPro-SemiBold;
  font-size: 14px;
  color: #fff;
  line-height: 1.2;
  text-transform: uppercase;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;

  box-shadow: 0 10px 30px 0px rgba(189, 89, 212, 0.5);
  -moz-box-shadow: 0 10px 30px 0px rgba(189, 89, 212, 0.5);
  -webkit-box-shadow: 0 10px 30px 0px rgba(189, 89, 212, 0.5);
  -o-box-shadow: 0 10px 30px 0px rgba(189, 89, 212, 0.5);
  -ms-box-shadow: 0 10px 30px 0px rgba(189, 89, 212, 0.5);

        }
        .user{
            width: 100px;
            padding: 100px;
            overflow: hidden;
            position: absolute;
            top:calc(-300px/2);
            left:calc(20% - 50px);
            border-radius: 50%;
        }
    
.text{
    font-size: 30px;
    font-family: sans-serif;
    
width:100%;
 height: auto;
 display: flex;
 align-items: flex-start;
 flex-wrap: wrap;
    
}
}
.login1{
  text-align: center;

}
button{
   text-align: center;
   color: white;
}

button {
  padding: 5px 20px;
  font-size: 16px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: white;
  background-color: #E933FF;
  border: none;
  border-radius: 15px;
  
}
button:hover {background-color: #49FF33}

button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
#a{
  color: white;
  text-align: center;
}

</style>
    </head>
     <body>
                
        <div class="loginBox">
                
                 
            <h2> Credit card</h2>
            <form method="post" action="payment.php">
                <p>Name on card</p>
                <input type="text" name="n" required autocomplete="off">
                <p>Card number</p>
                <input type="text" name="cn" placeholder="enter no"  required autocomplete="off">

                <p>Expiration</p>
                <input type="date" name="ex"  required autocomplete="off">
                <p>CVV</p>
                <input type="number" name="cv" plceholder="enter 3digit no"  required autocomplete="off">


                <div class="login1">
                           <button id="a" name="submit">Pay</button>
                </div>
                
                
            </form>
        </div>
    </body>
</html>
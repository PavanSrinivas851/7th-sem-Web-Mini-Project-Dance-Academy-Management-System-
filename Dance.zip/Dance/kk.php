<?php
include 'connect.php';
//session_start();
if(isset($_POST['submit'])){
    $UserID = $_POST['userid'];
    $Password = $_POST['pass'];
    $sql = "SELECT USERID,PASSWORD FROM reg WHERE USERID =?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$UserID);
    $stmt->execute();

    $stmt->bind_result($db_userid,$db_pass);
    if($stmt->fetch()){
        $pass_decode = password_verify($Password,$db_pass);
        
        if($pass_decode)
        {
            echo "login susseful";
            header("location:packages.html");
        }else{

            ?>
            <script>
                alert("incorrect password");
            </script>
        <?php
        }
    }else{
        echo "incorrect Userid...."; 
    }
    //echo $db_userid;
   // echo $db_pass;
}

?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>lohin.html</title>
    <link rel="stylesheet" href="a/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Quicksand">
    <link rel="stylesheet" href="a/css/login-form---Ambrodu-1.css">
    <link rel="stylesheet" href="a/css/login-form---Ambrodu.css">
    <link rel="stylesheet" href="a/css/OcOrato---Login-form-1.css">
    <link rel="stylesheet" href="a/css/OcOrato---Login-form.css">
    <link rel="stylesheet" href="a/css/styles.css">
</head>

<body>
    <!-- Start: OcOrato - Login form -->
    <form id="form" style="font-family:Quicksand, sans-serif;background-color:rgba(44,40,52,0.73);width:320px;padding:40px;" method="post" action="packages.html">
        <h1 id="head" style="color:rgb(193,166,83);">Login form</h1>
        <div><img class="rounded img-fluid" id="image" style="width:auto;height:auto;" src="assets/img/logo.png"></div>
        <div class="form-group"><input class="form-control" type="email" id="formum" name="userid" placeholder="Enter userID"></div>
        <div class="form-group"><input class="form-control" type="password" id="formum2" name="pass" placeholder="Password"></div>
        <div class="form-group"></div><button class="btn btn-light" id="butonas" style="width:100%;height:100%;margin-bottom:10px;background-color:rgb(106,176,209);" type="button" name="submit">Submit</button>
        </form>
    <!-- End: OcOrato - Login form -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
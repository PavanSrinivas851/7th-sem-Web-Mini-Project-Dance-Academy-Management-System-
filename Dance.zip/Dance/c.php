<?php
include 'connect.php';
if(isset($_POST['submit']))
{
  $Name = $_POST['name'];
  $Email = $_POST['email'];
  $Msg = $_POST['msg'];
  
  $sql = "INSERT INTO contact(NAME,EMAIL,MSG) VALUES(?,?,?)";
   
   $stmt = $conn->prepare($sql);
  $stmt->bind_param("sss",$Name,$Email,$Msg);//if the user need the parameter then use the bind_param
  $result = $stmt->execute();

  if($result)
  {
    ?>
    <script>
      alert(" We contact you shortly!!!!...")
      <?php
header("location:index.php");
      ?>
    </script>
    <?php
  }
}

?>


<!DOCTYPE html>

<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <title>online dance classes</title>
</head>
<body>
  <footer class="container-fluid p-0 pr-0">
    <div class="row mr-0 ml-0">
      <div class="col-md-6 pr-0 pl-0 map"> 
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d425765.65061521536!2d77.35073573336324!3d12.954517008640543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1670c9b44e6d%3A0xf8dfc3e8517e4fe0!2sBengaluru%2C%20Karnataka!5e1!3m2!1sen!2sin!4v1592490204886!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      
      <div class="col-md-6 content-us">
        <div class="contact-form" id="contact">
          <form method="post">
          <h3 class="text-uppercase">Contact me</h3>
          <input type="text" class="form-control" placeholder="Your Name"   name="name">
          <input type="text" class="form-control" placeholder="Your Email"  name="email">
          <textarea class="form-control" placeholder="Your Message" name="msg"></textarea>
          <button type="submit" name="submit">Send</button>
        </form>
        </div>
      </div>

    </div>
    </footer>

  <!-- jQuery first, then Popper.js, then Bootstrap JS --> 
  <script src="assets/js/jquery-3.3.1.slim.min.js"></script> 
  <script src="assets/js/popper.min.js" ></script> 
  <script src="assets/js/bootstrap.min.js"></script> 
  <script src="assets/js/owl.carousel.min.js"></script> 
  <script src="assets/js/main.js"></script>

</body>
</html>